
<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
		<form action="processing-RegistrationPage.php" method="POST">
	firstName: <input type="text" name="userName" />
	email: <input type="text" name="emailAddress" />
	passPhrase: <input type="text" name="password"/>
	<input type="submit" />
</form>
	</body>
</html>
