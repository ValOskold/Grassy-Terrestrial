
<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>WellnessTracker</title>
        <!-- <link rel="stylesheet" href="css/main.css" />
        <link rel="stylesheet" href="css/index.css" /> -->
        <link rel="stylesheet" href="css/login.css" />
        <style>

        </style>
    </head>
    <body>
        <!-- fixed header begin -->
        <header>
            <div class="h-center">
                <a href="index.html"><img id="logo" src="images/logo.svg" alt="logo" /></a>
            </div>
            
        </header>
        <!-- main content area begin -->
        <main>
            <!-- Enter information -->
            <section id="">
            <h1 id="please" class="h-center">Please enter your login information:</h1>
                <form action="" method="POST">
                    <fieldset class="flexbox" >
                    <label for="email">Email</label>
                    <input type="text" name="email" required />
                    <label for="password">Password</label>
                    <input type="text" name="password" required />
                    <a id="forgotA" class="h-center" href="#">Forgot Email / Password?</a>
                    </fieldset>
                    <hr>
                    <p id="footerP" class="h-center">Do not have an account? <a href="getstarted.php">Get Started here.</a></p>
                    <input  id="btn-submit" type="submit" value="Log in" name="submit" required />
                </form>
                
            </section>
            
            <footer>
                
            </footer>
        </main>
    </body>
</html>
S